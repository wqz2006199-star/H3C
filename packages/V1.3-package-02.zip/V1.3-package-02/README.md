# H3C 配置智能解析平台 V1.3 - 第二包

本包用于扩充统一 JSON 知识库，当前包含：
- ACL：基本 ACL、高级 ACL、规则、应用、查看
- OSPF：进程、Router-ID、Area、Network、静默接口、默认路由发布、邻居与路由查看
- Static Route：普通静态路由、默认路由、路由表、优先级/浮动静态路由

## 文件
knowledge_base/acl_ospf_static_route.json：统一知识库
examples/：三类配置示例

## 接入现有平台
读取 JSON 后，可以继续复用现有 command_db / analyzer / checker 的命令匹配逻辑。建议后续将 module 作为分类字段，将 errors 和 troubleshooting 用于 V1.4 检测规则。

## 注意
H3C Comware 不同版本、型号的命令参数可能存在差异。本包优先采用常见 Comware 写法，并在可能存在差异的位置进行了说明。部署到具体设备前应以对应版本命令参考为准。
