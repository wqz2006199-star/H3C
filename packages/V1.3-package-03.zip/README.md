# H3C 配置智能解析平台 V1.3 - 第二/第三扩展包

本包用于继续扩展 H3C/Comware 配置知识库，包含：
- DHCP
- NAT
- STP
- Link Aggregation（链路聚合）

## 文件
knowledge_base/dhcp_nat_stp_link_aggregation.json
examples/dhcp_example.txt
examples/nat_example.txt
examples/stp_example.txt
examples/link_aggregation_example.txt

## 注意
H3C 不同 Comware 版本、设备型号的命令支持和参数可能存在差异。
知识库中的命令用于常见场景，接入实际设备前应以对应版本官方命令参考为准。

## 接入方式
将 JSON 数组中的知识项合并到现有 V1.3 知识库即可。每项保持统一字段：
id、command、module、syntax、description、parameters、scenes、example、errors、troubleshooting、related_commands。
